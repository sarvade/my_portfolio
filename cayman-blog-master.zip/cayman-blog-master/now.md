---
layout: page
title: Now
tagline: What I'm doing now
permalink: /now.html
ref: now
order: 2
---

This is a [now page](https://nownownow.com/about), and it was inspired by [the /now movement](https://sivers.org/nowff). If you have your own site, [you should make one](https://nownownow.com/about), too.

[Go to the Home Page]({{ '/' | absolute_url }})
